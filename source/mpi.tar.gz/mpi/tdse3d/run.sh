#!/bin/bash
make clean; make all;
mpirun -np 2 tdse3d
