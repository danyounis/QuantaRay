import numpy as np
import matplotlib.pyplot as plt
from scipy.io import FortranFile

with FortranFile('Vp0.dat','r') as f:
    Vp0 = f.read_reals('float64').reshape((64,128,128), order='F')
with FortranFile('Vp1.dat','r') as f:
    Vp1 = f.read_reals('float64').reshape((64,128,128), order='F')

Vp = np.vstack((Vp0,Vp1))
print(Vp.shape)
del Vp0, Vp1

plt.imshow(Vp[63,:,:]), plt.show()
