# dummy.py
import numpy as np
from scipy.io import FortranFile

nx = 10
psi = np.random.uniform(0., 1., nx) \
 + 1j*np.random.uniform(0., 1., nx)

with FortranFile('Re_psi.dat','w') as f: f.write_record(psi.real)
with FortranFile('Im_psi.dat','w') as f: f.write_record(psi.imag)
