#!/bin/bash
#SBATCH --partition=standard
#SBATCH --nodes=16
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=1G
#SBATCH --time=5-00:00:00
#SBATCH --job-name=qray
#SBATCH --mail-user=ayounis@ur.rochester.edu
#SBATCH --mail-type=end

module unload gcc openmpi
module load gcc/9.1.0 openmpi/4.0.4/b4

mpirun -np 16 tdse2d stdin.deck
