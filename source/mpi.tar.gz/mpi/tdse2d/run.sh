#!/bin/bash
make clean; make all;
mpirun -np 4 tdse2d stdin.deck
